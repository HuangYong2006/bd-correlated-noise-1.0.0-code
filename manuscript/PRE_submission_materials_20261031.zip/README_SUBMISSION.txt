Manuscript PDF, editable LaTeX source package, and numerical supplement.
Provide innovation_controls_data_20261031.zip with the manuscript as supplementary data/code. It includes original failures, refinement, raw run arrays, code, seeds, hashes and a standalone verifier.
The completed control-size scope is stated in the manuscript and supplement.

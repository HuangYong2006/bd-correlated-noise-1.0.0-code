OVERLEAF SOURCE PACKAGE - PRE REVISION 2026-10-31
=====================================================
Upload overleaf_bd_paper.zip as an Overleaf project and compile main.tex using
pdfLaTeX and BibTeX. REVTeX 4.2 and the packages used are standard TeX Live
components. revision_results.tex and submission_results.tex supply numerical tables
and must stay beside main.tex and refs.bib. innovation_numbers.tex and
innovation_controls_results.tex supply the additional stationary controls.

This package uses a regenerated 105-cell comparison: three inputs, seven theta
values, five sizes, 64 independent runs per cell. Seven figures use corrected spectral data, including paired-filter
inference and fixed-record duration controls. All figure text is Times New Roman. The text distinguishes finite-size late-time slopes from
asymptotic exponents. It neither reports theta_c nor attributes errors to
previous authors. The former flat corrected KPZ-branch claim is withdrawn.

Files
  main.tex, refs.bib, revision_results.tex, submission_results.tex
  innovation_numbers.tex, innovation_controls_results.tex
  abstract_zh.md (reading aid, not part of the compiled manuscript)
  figs/fig1_generator through fig7_innovation_controls, each PDF and SVG

The stationary innovation controls have their own completed-size scope, stated
in the article and innovation_numbers.tex. They must not be confused with the
original five-size production grid. Their revision-local data are packaged
separately as innovation_controls_data_20261031.zip.

Old drafts are available in Git history, not in this source package.
Code/data reproduction is described in docs/REPRODUCE.md in the project.
Before actual submission the author must verify the revised interpretation
and supply the real corresponding email. Compilation alone does not certify
scientific readiness or acceptance.

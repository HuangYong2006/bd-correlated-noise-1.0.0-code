NUMERICAL SUPPLEMENT - INNOVATION CONTROLS

Completed sizes: 32 64 128 256 512; theta=0.10,0.25,0.40.
Each interface ensemble has 64 independent runs; binary-surrogate comparisons
use 32 held-out uniform-shared source runs. All seed/period parameters and
calibration metadata are in the NPZ archives. SEEDS.json explicitly lists
per-run seeds and their derivations; DATA_INDEX.json locates the original
failures, recalibrations and exact data fields. No pickle objects are needed.

Unzip this archive into an empty directory, then:
  python -m pip install -r requirements.txt
  python code/verify_submission_data.py
  python code/independent_supplement_audit.py
  python code/innovation_analysis.py --source data/raw/innovation_20261031_v3 --binary-source data/raw/innovation_binary_refined_20261031 --sizes 32 64 128 256 512 --out reproduced_analysis
  python code/update_innovation_manuscript.py --summary summary.json --figure-only

The final command recreates paper Figure7 as PDF/SVG/PNG without a TeX engine.
It preserves the numerical content; local font availability may affect typography.

The verifier checks every payload hash, recomputes slope/bootstrap contrasts
and independent covariance-validation bounds from the raw run arrays, and
reports which cells pass the unchanged0.005 threshold.
The independent audit imports no project generator or analysis functions.
It recomputes the original failures, current bounds, least-squares slopes,
bootstrap intervals and four-sign moments, reconstructs recalibrated spectra,
and regenerates a calibration record from its explicit seed for each refined
cell. It writes INDEPENDENT_AUDIT.json for inspection.

To regenerate the two refined cells from independent noise, run:
  python code/refine_binary_controls.py
This uses 128 fresh 64-site calibration records and 64 new 64-site validation
records per failed cell, fixed seed root 20261103 and separate seed domains.
The fit includes every lag 0..64 plus the original long lags. There are no
further fit retries using these fresh validation results and no tolerance relaxation.

The original failed archives remain under data/raw/innovation_binary_20261031_v3.
The refined archives and their metadata identify the original file and hash.
There are 12 byte-identical baseline archives in the selected grid.
The calibration records and fresh uniform covariance-reference records were
not used to fit interface exponents. Gaussian surrogate records supply both
interface trajectories and their baseline Gaussian covariance diagnostics.
Any additional covariance-only cohort is separate and supplies no interface
trajectories; its fixed-spectrum protocol and original failed archive are
identified in the cell metadata.

For the full five-size supplement, the additional L512 covariance-only cohort
can be regenerated with:
  python code/validate_large_binary_control.py
Its fixed fitted spectrum and original interface arrays are retained; 128 new
64-site Gaussian records and 128 independent 64-site uniform records verify
the same 0.005 criterion without changing fitted parameters or interface data.

Source snapshots record the exact earlier numerical producers. The current
scripts preserve their numerical model and add atomic file publication.
To regenerate a source campaign rather than analyze the supplied archives,
use a fresh output directory with code/innovation_controls.py; never overwrite
the archived evidence. Exact hashes identify archived bytes, while numerical
reproduction on other library versions should be assessed with tolerances.

summary.json contains 2000 whole-run bootstrap intervals. Inference is
conditional on the fitted surrogate spectrum; finite-lag covariance matching
does not establish equality of complete processes or asymptotic exponents.
